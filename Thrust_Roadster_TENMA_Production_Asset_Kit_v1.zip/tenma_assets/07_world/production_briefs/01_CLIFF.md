# Cliff launch — environment production brief

## Hero moment
Warm amber, slate graphite, mist canyon, readable launch ramp, 3 distance LODs, wind ribbons and 1 dramatic reveal.

## Required premium assets (not supplied)
- Modular GLB environment kit: 8–16 hero pieces + 12 reusable props, authored with mobile LODs.
- 1 hero sky/environment panoramic backdrop (equirectangular 2:1, 4096x2048 master; 2048x1024 mobile).
- PBR texture sets: albedo/baseColor, normal, ORM packed (occlusion-roughness-metallic); master 2048, mobile 512/1024.
- 4–8 VFX sprites/flipbooks (256–1024, transparent), with low-motion alternatives.
- 1 transition shot/storyboard, 1 chapter title treatment, 1 music stem set and 4–8 spatial SFX.

## Gameplay legibility
Obstacle and safe-route silhouettes distinguishable without color. Hazards have at least 0.7 s readable warning. 48 px minimum touch targets. Avoid excessive neon bloom.

## Export & QA
GLB glTF 2.0, meters, Y-up, +Z forward by project convention, apply transforms, no unlicensed embedded content. Texture dimensions power-of-two, mobile 30fps budget. Verify iPhone Safari on physical device.

## Acceptance
Environment tells player where to fly without tutorial text; no critical silhouette blends into background; transition maintains player agency.
