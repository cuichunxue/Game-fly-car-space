# Asset Quality Gates

G0 Brief: concept and rights clear; target audience and emotion defined.
G1 Art review: silhouette, color hierarchy, storytelling, consistency across five chapters.
G2 Technical: dimensions, UV, normal orientation, PBR maps, transparency, naming, looping, metadata.
G3 In-game: mobile readability, collision alignment, animation timing, sound latency, accessible alternate cues.
G4 Performance: test physical iPhone Safari, Android Chrome, desktop; 30fps sustained and no memory crash.
G5 Legal: full provenance/clearance ledger, trademark review, third-party notices.
G6 Player study: 5 novice + 5 experienced minimum; report confusion, delight, awe, replay desire.

Do not mark release-ready until all gates have owners, dated evidence, and PASS status. Generated SFX and procedural textures are design-stage assets pending in-game QA and mastering.
