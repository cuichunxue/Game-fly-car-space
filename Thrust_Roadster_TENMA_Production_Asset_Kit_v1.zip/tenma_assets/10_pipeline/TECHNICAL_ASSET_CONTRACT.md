# Technical Asset Contract

## Naming
`chapter_category_name_variant_lod.ext` in lowercase ASCII. Examples: `city_env_tower_a_lod1.glb`, `cosmos_vfx_asteroid_glow_01.ktx2`. Do not encode dates in filenames; track revision in manifest.

## Formats
- 3D: GLB/glTF2, physically based metallic-roughness, mesh LODs and collision proxies.
- Texture: source PNG/TIFF, delivery KTX2/BasisU where supported; sRGB for color, linear for data maps. Texture atlases for sprites.
- UI: SVG master; raster PNG exports at 1x/2x/3x as needed.
- Audio: source WAV 48kHz/24bit, delivery OGG/AAC; test iOS playback unlock.
- Font: OFL/commercially cleared only, document license; do not bundle font files without rights.

## Performance budget (starting targets; benchmark before freezing)
- iPhone Safari: 30fps sustained, 60fps stretch target; stable frame pacing.
- Draw calls <120 visible in gameplay; visible triangles <250k on midrange mobile; total GPU texture memory target <150MB.
- Particle count <=500 visible on mobile, <=200 in reduced graphics mode.
- Per-chapter initial payload target <=12MB compressed (excluding optional music), stream before boundary.
- 48px controls, minimum 14px HUD text, text contrast 4.5:1 where applicable.

## Legal/provenance
Every production asset needs creator, source, license, permitted uses, attribution obligations and proof of rights. Do not ship files labeled production_required. Perform title/trademark clearance before launch.
