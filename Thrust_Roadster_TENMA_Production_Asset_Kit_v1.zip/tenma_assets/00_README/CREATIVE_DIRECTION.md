# Art Direction Bible

## Visual thesis
The same iconic fictional vehicle crosses five worlds. Keep a consistent silhouette, light signature and UI while world lighting, motion language and musical texture evolve.

## Five chapter signatures
1. CLIFF — amber sunlight, graphite rock, monumental scale; fear then release.
2. ROADLESS CITY — teal/coral neon, layered air corridors, vertical facades; precision and freedom. No road surfaces required.
3. SKY BREAKER — blue-violet storm, golden shafts, rolling volumetric clouds; danger then catharsis.
4. COSMIC ODYSSEY — midnight indigo, starlight, soft Earth rim, sparse debris; awe and silence.
5. REENTRY — plasma orange, blue atmosphere, sunrise gold; controlled danger then homecoming.

## Camera language
Cliff: long focal-length anticipation then wide launch. City: readable parallax, limited shake. Sky: clouds part in a wide reveal. Space: motion slows and audio thins, planet fills horizon. Reentry: restrained vibration, ground grows gradually.

## Non-negotiables
Mobile readability; no strobing; no flash >3Hz; reduced-motion toggle; sound cues have visual twins; warm/non-violent family-safe tone; preserve player control outside explicitly signaled brief cinematic beats.

## Originality guardrails
Do not use Tesla branding, Roadster silhouette, licensed movie/game UI or soundtrack. Use original design geometry, unique brand, cleared typeface and original/licensed sounds.
