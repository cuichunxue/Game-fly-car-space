# THRUST ROADSTER — TENMA EDITION | ASSET PRODUCTION KIT v1.0

**Purpose:** Commercial-quality production handoff, NOT a finished commercial art/audio library. Contains original editable vector UI/brand concepts, generated procedural textures, synthetic sound effects, art briefs, asset manifest, and quality gates. Premium 3D models, key art, recorded/orchestrated music and full environments remain TO PRODUCE and must not be represented as delivered.

## Visual identity
- Original fictional car design. Avoid Tesla trademarks, distinctive Roadster bodywork and logos.
- Brand: TENMA EDITION / THRUST ROADSTER (working title; perform trademark clearance before release).
- Mood: cinematic, optimistic, legible, mysterious; grounded tactile surfaces + extraordinary worlds.
- Primary #0B1224, neon cyan #58E1F4, warm gold #FFCB70, danger coral #FF6A62, paper #F6F8FF.
- Text sizes: mobile HUD >= 14px; controls >= 48 CSS px; no critical information conveyed by color alone.

## What is actually inside
- 01_brand: original scalable vector logotype and app icon concepts.
- 02_ui: scalable SVG icons (each with 24px viewBox) and a HUD panel component.
- 03_ui: transparent 256px PNG exports for integration.
- 04_textures: 512px seamless original procedural textures and starfield background.
- 05_audio: generated short PCM WAV feedback cues; prototypes, not mastered final soundtrack.
- 06_audio: scene-by-scene original music composition briefs and implementation cue sheet.
- 07_world: five chapter environment and VFX production briefs.
- 08_vehicle: original vehicle design and 3D export contract.
- 09_vfx: original example shader snippets (adapt/QA before use).
- 10_pipeline: full manifest CSV/JSON, technical contracts, acceptance QA and licensing ledger.
- 11_reference: original requirements DOCX when available.

## Release blockers
1. Final vehicle and environment 3D models + texture sets + mobile LODs.
2. Final licensed/mastered adaptive score, detailed spatial SFX, VO/localization if used.
3. Final 5-stage skyboxes, particles, animations, cinematics and branding approval.
4. Device QA, accessibility testing, license provenance and performance profiling.

## Usage
Inspect `10_pipeline/ASSET_MANIFEST.csv`: `delivered` files are in ZIP, `production_required` are explicit missing deliverables. No third-party copyrighted art, brands or music are included. SVG/PNG/WAV are original procedural assets created for this package. Test all in target browser before release.
