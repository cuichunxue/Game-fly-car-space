precision mediump float;
varying vec2 vUv;
uniform float uTime;
uniform vec3 uColor;
void main(){vec2 p=vUv*2.0-1.0;float r=length(p);float ring=exp(-pow((r-0.72)*19.0,2.0));float pulse=0.7+0.3*sin(uTime*3.0+r*15.0);gl_FragColor=vec4(uColor*ring*pulse,ring*pulse);}
// Example fragment shader. Additive blend, disable depthWrite; mobile overdraw budget applies.
