precision mediump float;
varying vec3 vNormal;
varying vec3 vViewDir;
uniform vec3 uRimColor;
uniform float uIntensity;
void main(){float rim=pow(1.0-max(dot(normalize(vNormal),normalize(vViewDir)),0.0),3.0);gl_FragColor=vec4(uRimColor*rim*uIntensity,rim);}
// Example fragment shader. Requires vertex shader supplying vNormal/vViewDir; test mobile GPU.
