# Adaptive Score — composer brief (FINAL MUSIC NOT INCLUDED)

Original score, not derivative of movie, game or commercial songs. 48kHz / 24bit stereo masters; loopable stems at identical bar boundaries. Deliver OGG and AAC for browser plus lossless archive.

| Chapter | BPM | Musical mood | Stems | Transition |
| --- | ---: | --- | --- | --- |
| Cliff | 118 | tense pulse -> explosive freedom | pulse, bass, strings, impacts | launch downbeat |
| City | 136 | syncopated neon velocity | drums, arps, bass, atmos | wallride intensifies |
| Sky | 124 | storm tension -> soaring brass | low drone, percussion, strings, choir texture | clouds part |
| Cosmos | 78 | sparse awe, near silence | pad, glass tones, low pulse | 3-5s controlled quiet |
| Reentry | 142 | danger -> triumphant resolution | percussion, brass, strings, choir texture | landing final cadence |

### Interactive audio rules
- Threat meter 0..1 controls intensity stems; smooth gain over 250–750ms.
- Near-miss, rescue and checkpoint cues duck music gently, never > -6dB without listening QA.
- Player can mute music and SFX independently; respect reduced sensory settings.
- All important audio cues require matching visual feedback.
- Loop seam tests: no click, no unintended phase cancellation, no large LUFS jumps.
