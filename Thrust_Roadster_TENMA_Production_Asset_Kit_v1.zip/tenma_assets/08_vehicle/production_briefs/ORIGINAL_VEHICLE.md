# Original Hero Vehicle — production contract

**Important:** Avoid Tesla logos, trademarked styling and recognizable proprietary Roadster design. Create an original wedge-like flying GT with twin luminous lift fins and a unique triangular tail-light language.

## Deliverables (not yet produced)
- hero_vehicle.glb (LOD0 <= 45k triangles, LOD1 <= 15k, LOD2 <= 4k; targets, adjust after profiling)
- UV unwrapped PBR maps: baseColor, normal, ORM, emissive; 2048 master and 1024 mobile
- collision proxy <= 300 triangles; separate thruster pivots and wheel/fin rig controls
- 6 animation clips: idle, deploy_fins, boost, wallride, impact_recover, reentry
- silhouette sheet (front/side/top/three-quarter), material sheet, 3 colorways

## Art direction
Aerodynamic but not a real manufacturer clone. Distinctive illuminated X-shaped rear stabilizers, split glass canopy, sculpted underside air intakes. Primary obsidian with cyan accents; optional amber rescue mode.

## Technical contract
glTF 2.0, PBR metallic-roughness, Draco only if decoder shipped offline. Consistent scale in meters. Vehicle nose points +Z; Y-up. Set pivots for thrust and steering. Bake AO where needed. Validate materials in iOS Safari.
